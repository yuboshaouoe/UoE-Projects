package areas;

import java.util.ArrayList;

public abstract class NonHabitat implements IArea{

    public abstract ArrayList<Integer> getAdjacentAreas();
}
