package uk.ac.ed.inf;

/**
 * The Node record for recording each node when pathfinding
 */
public record Node(String orderNo,
                   double fromLongitude,
                   double fromLatitude,
                   Double angle,
                   double toLongitude,
                   double toLatitude,
                   Integer ticks) {

}
