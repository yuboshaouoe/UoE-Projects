package uk.ac.ed.inf;

import org.javatuples.Triplet;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * The order manager class filters the invalid orders and sort the remaining orders by the one-way distance
 * between the destination restaurant and Appleton Tower in ascending order.
 */
public class OrderManager {

    private ArrayList<Delivery> outcomes = new ArrayList<>();
    private ArrayList<Triplet<Order, Restaurant, Double>> validOrders = new ArrayList<>();

    /**
     * Filters the all placed orders of the day and sort them based on straight-line distance from order restaurant
     * to Appleton Tower
     */
    public OrderManager(Order[] orders, Restaurant[] restaurants, LngLat dest){
        filterAndSortOrders(orders, restaurants, dest);
    }

    private void filterAndSortOrders(Order[] orders, Restaurant[] restaurants, LngLat dest){
        System.out.println("Order checking and sorting started!");
        for (Order order : orders) {
            if (!order.isValid()) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.Invalid.toString(),
                        order.priceTotalInPence()));
                continue;
            }
            if (!order.isCorrectCredNo()) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.InvalidCardNumber.toString(),
                        order.priceTotalInPence()));
                continue;
            }
            if (!order.isCorrectCvv()) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.InvalidCvv.toString(),
                        order.priceTotalInPence()));
                continue;
            }
            if (!order.isExpired()) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.InvalidExpiryDate.toString(),
                        order.priceTotalInPence()));
                continue;
            }

            if (!order.isCorrectPizza(restaurants)) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.InvalidPizzaNotDefined.toString(),
                        order.priceTotalInPence()));
                continue;
            }
            if (!order.isCorrectCount()) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.InvalidPizzaCount.toString(),
                        order.priceTotalInPence()));
                continue;
            }
            if (!order.isCorrectCombination(restaurants)) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.InvalidPizzaCombinationMultipleSuppliers.toString(),
                        order.priceTotalInPence()));
                continue;
            }
            if (!order.isCorrectTotal(restaurants)) {
                outcomes.add(new Delivery(
                        order.orderNo(),
                        OrderOutcome.InvalidTotal.toString(),
                        null));
                continue;
            }
            validOrders.add(order.distToRest(restaurants, dest));
        }
        validOrders.sort(Comparator.comparingDouble(Triplet::getValue2));
        System.out.println("Order checking and sorting completed!");
    }

    public ArrayList<Delivery> getOutcomes() {
        return outcomes;
    }

    public ArrayList<Triplet<Order, Restaurant, Double>> getValidOrders() {
        return validOrders;
    }
}
