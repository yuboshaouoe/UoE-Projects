package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.javatuples.Triplet;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * The Order record for getting the delivery cost and catching errors with order
 */
public record Order(@JsonProperty("orderNo") String orderNo,
                    @JsonProperty("orderDate") String orderDate,
                    @JsonProperty("customer") String customer,
                    @JsonProperty("creditCardNumber") String creditCardNumber,
                    @JsonProperty("creditCardExpiry") String creditCardExpiry,
                    @JsonProperty("cvv") String cvv,
                    @JsonProperty("priceTotalInPence") int priceTotalInPence,
                    @JsonProperty("orderItems") String[] orderItems) {

    /**
     * Convert the order object into a triplet of info to later be used for sorting and path searching
     * @param restaurants the list of participating restaurants
     * @param start the starting point of trip
     * @return a triplet of the order object itself, the closest restaurant that satisfies the order,
     *         and distance to that restaurant
     */
    public Triplet<Order, Restaurant, Double> distToRest(Restaurant[] restaurants, LngLat start){
        Restaurant restaurant = getSatisfyingRestaurants(restaurants).get(0);
        return new Triplet<>(this, restaurant,
                start.distanceTo(new LngLat(restaurant.lng(), restaurant.lat())));
    }

    /**
     * @return the bool of if this order has a correct orderDate
     */
    public Boolean isValid(){
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");
            String date = "01/" + creditCardExpiry;
            LocalDate.parse(date, formatter);
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate.parse(orderDate, formatter);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    /**
     * @return the bool of if this credit card used for this order has a correct credit card number
     */
    public Boolean isCorrectCredNo() {
        return (creditCardNumber.matches("\\d+") && !(creditCardNumber.length() != 16 ||
                (creditCardNumber.charAt(0) != '4' && creditCardNumber.charAt(0) != '5' &&
                        Integer.parseInt(creditCardNumber.substring(0, 3)) > 2720 &&
                        Integer.parseInt(creditCardNumber.substring(0, 3)) < 2221)));
    }

    /**
     * @return the bool of if the used credit card is expired
     */
    public Boolean isExpired(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");
        String date = "01/" + creditCardExpiry;
        LocalDate expiry = LocalDate.parse(date, formatter).plusMonths(1);
        formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate orderDateStr = LocalDate.parse(orderDate, formatter);
        return orderDateStr.isBefore(expiry);
    }

    /**
     * @return the bool of if the used credit card is a correct cvv
     */
    public Boolean isCorrectCvv() {
        return cvv.length() == 3;
    }

    /**
     * @return the bool of if ordered pizzas all exists
     */
    public Boolean isCorrectPizza(Restaurant[] restaurants) {
        return new ArrayList<>(new HashSet<>(Arrays.stream(Objects.requireNonNull(restaurants))
                .map(Restaurant::getMenuNames)
                .flatMap(Collection::stream)
                .toList())).containsAll(Arrays.asList(orderItems));
    }

    /**
     * @return the bool of if ordered pizzas are within number limit
     */
    public Boolean isCorrectCount() {
        return orderItems.length > 0 && orderItems.length < 5;
    }

    private List<Restaurant> getSatisfyingRestaurants(Restaurant[] restaurants) {
        return Arrays.stream(Objects.requireNonNull(restaurants))
                .filter(restaurant -> new HashSet<>(restaurant.getMenuNames())
                        .containsAll(Arrays.asList(orderItems)))
                .toList();
    }

    /**
     * @return the bool of if ordered pizzas can be all made by one restaurant
     */
    public Boolean isCorrectCombination(Restaurant[] restaurants) {
        return getSatisfyingRestaurants(restaurants).size() != 0;
    }

    /**
     * @return the bool of if cost of the order adds up to the right number according to the menu
     */
    public Boolean isCorrectTotal(Restaurant[] restaurants) {
        Menu[] satisfyingMenu = getSatisfyingRestaurants(restaurants).get(0).getMenu();
        List<Menu> orderedItems = Arrays.stream(satisfyingMenu).filter(menu ->
                List.of(orderItems).contains(menu.name())).toList();
        int itemTotalPrice = orderedItems.stream().map(Menu::price).mapToInt(Integer::intValue).sum();
        return itemTotalPrice + 100 == priceTotalInPence;
    }
}
