package uk.ac.ed.inf;

import java.util.HashMap;
import java.util.Map;
/**
 * This Enum class represents the allowed 16 directions for the drone.
 * The angle of direction is presented in radians, starting from EAST counterclockwise.
 */
public enum CompassDirection {
    E(0),
    ENE(Math.PI/8),
    NE(Math.PI/4),
    NNE(3*Math.PI/8),
    N(Math.PI/2),
    NNW(5*Math.PI/8),
    NW(3*Math.PI/4),
    WNW(7*Math.PI/8),
    W(Math.PI),
    WSW(9*Math.PI/8),
    SW(5*Math.PI/4),
    SSW(11*Math.PI/8),
    S(3*Math.PI/2),
    SSE(13*Math.PI/8),
    SE(7*Math.PI/4),
    ESE(15*Math.PI/8);

    /**
     * This field provides a cache for the angles and the directions.
     * It prevents the program to search through all directions for angles
     * everytime a movement is about to be made.
     */
    private static final Map<CompassDirection, Double> Angles = new HashMap<>();
    /*
      Caching the angles and directions
     */
    static {
        for (CompassDirection d : values()){
            Angles.put(d, d.angle);
        }
    }
    /**
     * angle Field for the directions
     */
    public final double angle;

    CompassDirection(double angle) {
        this.angle = angle;
    }
    /**
     * Static method for getting the angle of a compass direction through the cached Map
     * @param d a compass direction
     * @return the angle of the compass direction
     */
    public static double angleOfDirection(CompassDirection d){
        return Angles.get(d);
    }
}
