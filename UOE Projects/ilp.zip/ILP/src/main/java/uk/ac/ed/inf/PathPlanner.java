package uk.ac.ed.inf;

import org.javatuples.Pair;
import org.javatuples.Triplet;

import java.util.*;
import java.util.stream.Stream;

/**
 * PathPlanner class constructs the flight path of a specific date using A* search
 */
public class PathPlanner {

    private final NoFlyZones[] noFlyZones;
    private final CentralArea[] centralAreas;
    private final LngLat appletonTower = new LngLat(-3.186874, 55.944494);
    private final OrderManager orderManager;

    /**
     * pathBuffer buffers the searched paths and prevent unnecessary path searching for orders with the same
     * destinations.
     */
    private HashMap<Restaurant, List<Node>> pathBuffer = new HashMap<>();

    /**
     * outcomes to be serialized to deliveries.json file
     */
    private List<Delivery> outcomes;

    /**
     * LngLat to be serialized to drone.geojson file
     */
    private List<LngLat> geoJSONPath = new ArrayList<>();

    /**
     * Nodes to be serialized to flightpath.json file
     */
    private List<Node> JSONPath = new ArrayList<>();

    /**
     * Construct the Collections of order outcomes, Lnglat objects, and Nodes to prepare for file generation
     * @param dateStr the string of specific date (DateTime check performed in fileGenerator)
     */
    public PathPlanner(String url, String dateStr) {
        noFlyZones = AccessREST.getNoFlyZones(url);
        centralAreas = AccessREST.getCentralArea(url);
        orderManager = new OrderManager(
                AccessREST.getOrdersOfDate(url, dateStr),
                AccessREST.getRestaurants(url),
                appletonTower);
        getFullPath(orderManager.getValidOrders(), 2000);
        outcomes = orderManager.getOutcomes();
        System.out.println("Obtained full path for " + dateStr);
    }

    private List<Node> checkFullPathBuffer(Triplet<Order, Restaurant, Double> orderEntry){
        if (pathBuffer.containsKey(orderEntry.getValue1())) {
            return pathBuffer.get(orderEntry.getValue1());
        } else {
            return getFullPathOfOrder(orderEntry);
        }
    }

    /**
     * Construct the full day path for all orders until the battery cannot sustain
     * a full round-trip for the next order in line.
     * Uses the buffered path if the destination restaurant is the same between orders.
     * @param orderEntries all valid order entries of a day
     * @param battery the size of the full battery
     */
    private void getFullPath(ArrayList<Triplet<Order, Restaurant, Double>> orderEntries, int battery) {
        var finalOutcomes = orderManager.getOutcomes();
        List<Triplet<Order, Restaurant, Double>> deliveredEntries = new ArrayList<>();
        List<Node> fullDayPath = new ArrayList<>();
        int remainingBattery = battery;
        for (Triplet<Order, Restaurant, Double> orderEntry : orderEntries) {
            var orderPath = checkFullPathBuffer(orderEntry);
            if (remainingBattery > Objects.requireNonNull(orderPath).size()) {
                fullDayPath = Stream.concat(fullDayPath.stream(), orderPath.stream()).toList();
                // add delivered orders to orderOutcomes
                finalOutcomes.add(new Delivery(
                        orderEntry.getValue0().orderNo(),
                        OrderOutcome.Delivered.toString(),
                        orderEntry.getValue0().priceTotalInPence()));
                deliveredEntries.add(orderEntry);
                remainingBattery = remainingBattery - orderPath.size();
            } else {
                break;
            }
        }
        orderEntries.removeAll(deliveredEntries);
        // add all valid but not delivered orders to orderOutcomes
        finalOutcomes.addAll(orderEntries.stream().map(entry ->
                new Delivery(
                        entry.getValue0().orderNo(),
                        OrderOutcome.ValidButNotDelivered.toString(),
                        entry.getValue0().priceTotalInPence())).toList());
        outcomes = finalOutcomes;
        geoJSONPath = fullDayPath.stream().map(node -> new LngLat(node.fromLongitude(), node.fromLatitude())).toList();
        JSONPath = fullDayPath;
    }

    /**
     * Obtain the round-trip path for a specific order by getting the one-way path and reversing it,
     * the hover step for both ways are added while constructing the full path
     * @param orderEntry the order to be delivered
     * @return the round-trip path between a specific order
     */
    private List<Node> getFullPathOfOrder(Triplet<Order, Restaurant, Double> orderEntry) {
        LngLat dest = new LngLat(orderEntry.getValue1().lng(), orderEntry.getValue1().lat());
        try {
            var oneWayPath = aStarSearch(appletonTower, dest, orderEntry.getValue0());
            List<Node> reversePath = new ArrayList<>();
            long timeStart = System.nanoTime();
            for (Node node : Objects.requireNonNull(oneWayPath)) {
                // reverse the one-way path
                reversePath.add(0, new Node(
                        node.orderNo(),
                        node.toLongitude(),
                        node.toLatitude(),
                        ((node.angle() + Math.PI) % (2 * Math.PI)),
                        node.fromLongitude(),
                        node.fromLatitude(),
                        getTime(timeStart)));
            }
            // add the hover steps
            oneWayPath.add(getHoverNode(orderEntry.getValue0().orderNo(), dest, getTime(timeStart)));
            reversePath.add(getHoverNode(orderEntry.getValue0().orderNo(), appletonTower, getTime(timeStart)));
            var path = Stream.concat(oneWayPath.stream(), reversePath.stream()).toList();
            // buffer the found round-trip path
            if (!pathBuffer.containsKey(orderEntry.getValue1())) {
                pathBuffer.put(orderEntry.getValue1(), path);
            }
            return path;
        } catch (Exception e) {
            System.err.println("Path searching failed, there isn't a path to reach the destination.");
        }
        return null;
    }

    private Node getHoverNode(String orderNo, LngLat pos, int time) {
        return new Node(orderNo, pos.lng(), pos.lat(), null, pos.lng(), pos.lat(), time);
    }

    /**
     * A* search algorithm for finding the shortest path between LngLat objects
     * there is no initial and finishing hover step
     * @param start start point of the path
     * @param dest destination of the path
     * @param order the order delivery of this path
     * @return the one-way path from start to destination
     * @link <a href="https://en.wikipedia.org/wiki/A">...</a>*_search_algorithm
     */
    private List<Node> aStarSearch(LngLat start, LngLat dest, Order order) {
        long timeStart = System.nanoTime();
        Set<LngLat> openSet = new HashSet<>();
        openSet.add(start);

        HashMap<LngLat, Triplet<LngLat, CompassDirection, Integer>> cameFrom = new HashMap<>();

        HashMap<LngLat, Double> gScore = new HashMap<>();
        gScore.put(start, (double) 0);

        HashMap<LngLat, Double> fScore = new HashMap<>();
        fScore.put(start, gScore.get(start) + start.distanceTo(dest));

        int counter = 0;
        boolean isInCentral = true;
        while (!openSet.isEmpty() && counter < 5000) {
            counter++;
            // get the node with the lowest f score in the discovered nodes
            LngLat current = getLowestMapNode(openSet, fScore);
            if (!current.inCentralArea(centralAreas)) {
                isInCentral = false;
            }
            if (current.closeTo(dest)) {
                return reconstructPath(cameFrom, current, order);
            }
            openSet.remove(current);
            for (CompassDirection d : CompassDirection.values()){
                var neighbor = current.nextPosition(d);
                if (current.intersects(noFlyZones, neighbor) ||
                        (!isInCentral && neighbor.inCentralArea(centralAreas))) {
                    continue;
                }
                // g score of node + path weight (step cost)
                double tentativeGScore = mapGet(gScore, current) + 0.00015;
                if (tentativeGScore < mapGet(gScore, neighbor)) {
                    cameFrom.put(neighbor, new Triplet<>(current, d, getTime(timeStart)));
                    gScore.put(neighbor, tentativeGScore);
                    fScore.put(neighbor, tentativeGScore + neighbor.distanceTo(dest));
                    if (!openSet.contains(neighbor)){
                        openSet.add(neighbor);
                    }
                }
            }
        }
        return null;
    }

    private List<Node> reconstructPath(HashMap<LngLat, Triplet<LngLat, CompassDirection, Integer>> cameFrom,
                                       LngLat curr,
                                       Order order) {
        var current = curr;
        List<Node> totalPath = new ArrayList<>();
        // rebuilt the cheapest path from discovered nodes
        while (cameFrom.containsKey(current)) {
            var prev = cameFrom.get(current).getValue0();
            var angle = cameFrom.get(current).getValue1().angle;
            var time = cameFrom.get(current).getValue2();
            totalPath.add(0, new Node(
                    order.orderNo(),
                    prev.lng(),
                    prev.lat(),
                    angle,
                    current.lng(),
                    current.lat(),
                    time));
            current = prev;
        }
        return totalPath;
    }

    private LngLat getLowestMapNode(Set<LngLat> openSet, HashMap<LngLat, Double> map) {
        var mappedQueue = new ArrayList<>(openSet.stream().map(node -> new Pair(node, mapGet(map, node))).toList());
        mappedQueue.sort(Comparator.comparingDouble(pair -> (double) pair.getValue1()));
        return (LngLat) mappedQueue.get(0).getValue0();
    }

    private Double mapGet(HashMap<LngLat, Double> map, LngLat key) {
        map.putIfAbsent(key, Double.POSITIVE_INFINITY);
        return map.get(key);
    }

    private int getTime(long timeStart) {
        long timeStop = System.nanoTime();
        return (int)(timeStop - timeStart);
    }

    public List<Delivery> getOutcomes() {
        return outcomes;
    }

    public List<LngLat> getGeoJSONPath() {
        return geoJSONPath;
    }

    public List<Node> getJSONPath() {
        return JSONPath;
    }
}
