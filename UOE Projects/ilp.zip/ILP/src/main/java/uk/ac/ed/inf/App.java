package uk.ac.ed.inf;


/**
 * Main manifest file
 */
public class App 
{
    public static void main( String[] args ) {
        //AccessREST.downloadFile("all.geojson");
        //FileGenerator.createFilesForDate("https://ilp-rest.azurewebsites.net", "2023-02-28");
        FileGenerator.createFilesForDate(args[1], args[0]);
    }
}
