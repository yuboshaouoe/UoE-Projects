package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonProperty;

/*
* Each Menu object represents a menu item
* It also has class arguments with @JsonProperty to be used with ObjectMapper for
* deserialization.
 */
public record Menu(@JsonProperty("name") String name,
                   @JsonProperty("priceInPence") int price){
}
