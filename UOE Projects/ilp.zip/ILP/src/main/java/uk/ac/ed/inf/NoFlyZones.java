package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

/**
 * The NoFlyZone record for object mapping
 */
public record NoFlyZones(@JsonProperty("name") String name,
                         @JsonProperty("coordinates") ArrayList<ArrayList<Double>> coordinates) {
}
