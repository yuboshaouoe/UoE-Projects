package uk.ac.ed.inf;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * The LngLat record represents the position of buildings, areas and addresses.
 */
public record LngLat (double lng, double lat){
    /**
     * Check if this LngLat object is within the Central Area.
     * It gets the coordinates of vertices from the "centralArea" endpoint on REST server.
     * @return boolean of if this LngLat object is in the Central Area
     */
    public boolean inCentralArea(CentralArea[] corners){
        int nVert = Objects.requireNonNull(corners).length;
        List<Double> lngs = Arrays.stream(corners).map(CentralArea::lng).toList();
        List<Double> lats = Arrays.stream(corners).map(CentralArea::lat).toList();
        return rayCasting(nVert, lngs, lats, lng, lat);
    }

    /**
     * Check if this LngLat object and the straight-line path to a given neighbor intersects/crosses through
     * a no-fly zone.
     * It gets the coordinates of vertices of each no-fly zone form the REST server.
     * @param zones the array of no-fly zones
     * @param neighbor the target neighbor in the straight-line path
     * @return boolean of if the straight-line path crosses a no-fly zone
     */
    public boolean intersects(NoFlyZones[] zones, LngLat neighbor){
        boolean intersect = false;
        Line2D path = getNewLine(this, neighbor);
        for (NoFlyZones zone : Objects.requireNonNull(zones)) {
            List<Point2D> vertices = Objects.requireNonNull(getVertices(zone));
            for (int i = 0; i < vertices.size() - 1; i++) {
                intersect = path.intersectsLine(
                        vertices.get(i).getX(),
                        vertices.get(i).getY(),
                        vertices.get(i+1).getX(),
                        vertices.get(i+1).getY());
                if (intersect) {
                    break;
                }
            }
            if (!intersect) {
                intersect = path.intersectsLine(
                        vertices.get(vertices.size() - 1).getX(),
                        vertices.get(vertices.size() - 1).getY(),
                        vertices.get(0).getX(),
                        vertices.get(0).getY());
            } else {
                break;
            }
        }
        return intersect;
    }

    private Line2D getNewLine(LngLat start, LngLat end) {
        Line2D.Double line = new Line2D.Double();
        line.x1 = start.lng();
        line.y1 = start.lat();
        line.x2 = end.lng();
        line.y2 = end.lat();
        return line;
    }

    private List<Point2D> getVertices(NoFlyZones noFlyZones){
        List<Point2D> vertices = new ArrayList<>();
        for (ArrayList<Double> coordinate : noFlyZones.coordinates()){
            vertices.add(new Point2D.Double(coordinate.get(0), coordinate.get(1)));
        }
        return vertices;
    }

    /**
     * Using Ray Casting Algorithm to check if a point is within a polygon
     * As PNPOLY cannot check points on edges and corners, this method added
     * a clause to check if the point is on edges/corners.
     * The logic of this method referenced the PNPOLY algorithm
     * @param numVert Number of vertices of the polygon
     * @param lngs The longitudes of the vertices
     * @param lats The latitudes of the vertices
     * @param pointLng The longitude of the point
     * @param pointLat The lat of the point
     * @return whether the point is inside the polygon
     * @link <a href="https://wrfranklin.org/Research/Short_Notes/pnpoly.html#Explanation">...</a>
     */
    private boolean rayCasting(int numVert, List<Double> lngs, List<Double> lats, double pointLng, double pointLat){
        boolean isInside = false;
        for (int i = 0, j = numVert-1; i < numVert; j = i++){
            // if the point is on an edge or corner
            if (pointLng == (lngs.get(j) - lngs.get(i)) * (pointLat - lats.get(i)) /
                    (lats.get(j) - lats.get(i)) + lngs.get(i)){
                return true;
            }
            // if the ray crosses an edge
            if (lats.get(i) > pointLat != lats.get(j) > pointLat &&
                    pointLng < (lngs.get(j) - lngs.get(i)) * (pointLat - lats.get(i)) /
                            (lats.get(j) - lats.get(i)) + lngs.get(i)
            ){
                isInside = !isInside;
            }
        }
        return isInside;
    }

    /**
     * Determine the distance from this LngLat object to another LngLat object.
     * @param target the other LngLat object
     * @return the distance between the two objects
     */
    public double distanceTo(LngLat target){
        return Math.sqrt(Math.pow(lng - target.lng(), 2) +
                         Math.pow(lat - target.lat(), 2));
    }
    /**
     * Determine if this LngLat object is close to another LngLat object,
     * threshold = 0.00015
     * @param target the other LngLat object
     * @return boolean of if this object is close to the other
     */
    public boolean closeTo(LngLat target){
        return distanceTo(target) <= 0.00015;
    }
    /**
     * Determine what would the next position of this LngLat object be if it were to move
     * in one of the 16 pre-determined directions.
     * Movement Distance = 0.00015
     * @param d an Enum, one of the 16 compass directions
     * @return the LngLat object of the next position
     */
    public LngLat nextPosition(CompassDirection d){
        return new LngLat(lng + 0.00015 * Math.cos(CompassDirection.angleOfDirection(d)),
                          lat + 0.00015 * Math.sin(CompassDirection.angleOfDirection(d)));
    }
}
