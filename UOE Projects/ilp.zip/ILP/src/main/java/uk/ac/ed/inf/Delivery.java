package uk.ac.ed.inf;

/*
 * Each Delivery object represents the outcome for a placed order
 */
public record Delivery(String orderNo,
                       String outcome,
                       Integer costInPence) {
}
