package uk.ac.ed.inf;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.LineString;
import com.mapbox.geojson.Point;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.List;

/**
 * fileGenerator create the result files for a specific date
 */
public class FileGenerator {


    private static boolean dateValidation(String dateStr) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("uuuu-MM-dd")
                .withResolverStyle(ResolverStyle.STRICT);
        try {
            LocalDate.parse(dateStr, dateTimeFormatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

    /**
     * creates all result files for the given date
     * @param dateStr the string of a specific date
     */
    public static void createFilesForDate(String url, String dateStr) {
        if (dateValidation(dateStr)){
            PathPlanner pathPlanner = new PathPlanner(url, dateStr);
            System.out.println("Number of delivered orders: " +
                    pathPlanner.getOutcomes().stream().filter(delivery ->
                                    delivery.outcome().equals(OrderOutcome.Delivered.toString())).toArray().length);
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                // flightpath file
                objectMapper.writeValue(new File("flightpath-" + dateStr + ".json"),
                        pathPlanner.getJSONPath());

                // deliveries file
                objectMapper.writeValue(new File("deliveries-" + dateStr + ".json"),
                        pathPlanner.getOutcomes());

                List<Point> pathPoints = pathPlanner.getGeoJSONPath().stream()
                        .map(node -> Point.fromLngLat(node.lng(), node.lat())).toList();
                String featureCollectionJSON =
                        FeatureCollection.fromFeature(
                        Feature.fromGeometry(
                                LineString.fromLngLats(pathPoints))).toJson();

                // drone file
                Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
                                "drone-" + dateStr + ".geojson"),
                        StandardCharsets.UTF_8));
                writer.write(featureCollectionJSON);
                writer.close();
                System.out.println("Files are written!");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            System.err.println("Incorrect DateTime format: " + dateStr);
        }
    }
}
