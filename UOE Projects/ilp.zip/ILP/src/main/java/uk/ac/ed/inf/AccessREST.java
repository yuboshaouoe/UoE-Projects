package uk.ac.ed.inf;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Singleton class for accessing REST server
 */
public class AccessREST {
    AccessREST instance;
    private AccessREST(){
    }

    /**
     * Getting an instance of the singleton class
     * @return an instance of the singleton class
     */
    public AccessREST getInstance() {
        if(instance == null) {
            instance = new AccessREST();
        }
        return instance;
    }

    /**
     * Retrieve the central area data from the centralArea end point and deserialize it
     * @param url URL of REST service
     * @return array of centralArea objects
     */
    public static CentralArea[] getCentralArea(String url){
        try {
            return new ObjectMapper().readValue(
                    new URL(url + "/centralArea"),
                    CentralArea[].class);
        } catch (IOException e) {
            System.err.println("Malformed URL: " + url);
        }
        return null;
    }

    /**
     * Retrieve the JSON string from the server and deserialize it with ObjectMapper
     * @param url URL of REST service
     * @return the array of Restaurants objects of all participating restaurants
     */
    public static Restaurant[] getRestaurants(String url){
        try {
            return new ObjectMapper().readValue(
                    new URL(url + "/restaurants"),
                    Restaurant[].class);
        } catch (IOException e) {
            System.err.println("Malformed URL: " + url);
        }
        return null;
    }

    /**
     * Retrieve the JSON string from the server and deserialize it with ObjectMapper
     * @param url URL of REST service
     * @param dateStr the string of a specific date (format checks are done in class fileGenerator)
     * @return the array of Order objects of a specific date
     */
    public static Order[] getOrdersOfDate(String url, String dateStr){
        try {
            return new ObjectMapper().readValue(
                        new URL(url + "/orders/" + dateStr),
                        Order[].class);
        } catch (IOException e) {
            System.err.println("Malformed URL: " + url + "/orders/" + dateStr);
        }
        return null;
    }

    /**
     * Retrieve the JSON string from the server and deserialize it with ObjectMapper
     * @param url URL of REST service
     * @return the array of NoFlyZones objects
     */
    public static NoFlyZones[] getNoFlyZones(String url){
        try {
            return new ObjectMapper().readValue(
                    new URL(url + "/noFlyZones"),
                    NoFlyZones[].class);
        } catch (IOException e) {
            System.err.println("Malformed URL: " + url);
        }
        return null;
    }

    /**
     * Retrieve the JSON string from the server and deserialize it with ObjectMapper
     * @param url URL of REST service
     * @param filename name of the file to be downloaded
     */
    public static void downloadFile(String url, String filename) {
        try {
           var URL = new URL(url + filename);
           try {
               BufferedInputStream in = new BufferedInputStream(URL.openStream());
               FileOutputStream fileOutputStream =
                       new FileOutputStream(filename, false);
               byte[] dataBuffer = new byte[4096];
               int bytesRead;
               while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                   fileOutputStream.write(dataBuffer, 0, bytesRead);
               }
               System.out.println("File written: " + filename);
           } catch (IOException e) {
               System.err.println("Error loading file: " + filename);
           }
        } catch (MalformedURLException e) {
            System.err.println("Incorrect URL");
        }
    }
}
