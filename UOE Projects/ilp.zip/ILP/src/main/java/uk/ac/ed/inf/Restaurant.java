package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Arrays;
import java.util.List;

/**
 * The Restaurant record represents the participating restaurants retrieved from the Rest server.
 * It also has class arguments with @JsonProperty to be used with ObjectMapper for
 * deserialization.
 */
public record Restaurant(@JsonProperty("name") String name,
                         @JsonProperty("longitude") double lng,
                         @JsonProperty("latitude") double lat,
                         @JsonProperty("menu") Menu[] menu) {

    /**
     * Getter for the Menu
     * @return menu of this Restaurant object
     */
    public Menu[] getMenu(){
        return menu;
    }

    /**
     * Getting just the names of each item on the menu of this Restaurant object
     * @return a list of the names of each menu item
     */
    public List<String> getMenuNames(){return Arrays.stream(menu).map(Menu::name).toList();}
}
