package uk.ac.ed.inf;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * An instance of centralArea record represents a corner of the central area.
 * It also has class arguments with @JsonProperty to be used with ObjectMapper for
 * deserialization.
 */
public record CentralArea(@JsonProperty("name") String name,
                          @JsonProperty("longitude") double lng,
                          @JsonProperty("latitude") double lat) {
}
