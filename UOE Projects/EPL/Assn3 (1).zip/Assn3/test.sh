#!/bin/sh
scala -cp target/scala-2.11/assignment-3_2.11-0.1.0-SNAPSHOT.jar:lib/com.sksamuel.scrimage.scrimage-core-4.0.32.jar:lib/com.drewnoakes.metadata-extractor-2.18.0.jar Assignment3.RabbitStandalone.Assignment3Standalone -t $1
